sample: [
    integer-list: [[to-integer to-float] ["founded_year"]] 
    float-list: [[to-float] []] 
    bool-list: [[reduce to-word] ["usa_resident"]] 
    string-list: [[to-string] []]
] 
