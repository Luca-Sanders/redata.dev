sample: [
    inject-tag-to-every-children: [] 
    enumerate-nodes: [] 
    change-value-for-this-tag: [] 
    injection-tag-and-recipients: [
        company_name: [department]
    ]
]