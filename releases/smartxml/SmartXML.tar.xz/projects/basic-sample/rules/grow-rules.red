sample: [
    customer: ["customer"] 
    department: ["department"]
] 
