#[
    sample: #[
        company_name: [
            "customers customer name"
        ]
        key_person: [
            "customers customer keyPerson"
        ]
        usa_resident: [
            "customers customer UsaResident"
        ]
        founded_year: [
            "customers customer foundedYear"
        ]
        department_name: [
            "customers customer department name"
        ]
        department_address: [
            "customers customer department address"
        ]
    ]
]