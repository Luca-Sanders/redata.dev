sample: [
    customers: [company_name] 
    departments: [company_name department_name]
] 
