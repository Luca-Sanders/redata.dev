#[
    sample: #[
        sample: #[
            customers: [
                customer: [
                    company_name: none 
                    key_person: none 
                    usa_resident: none 
                    founded_year: none 
                    departments: [
                        department: [
                            department_name: none 
                            department_address: none
                        ]
                    ]
                ]
            ]
        ]
    ]
]