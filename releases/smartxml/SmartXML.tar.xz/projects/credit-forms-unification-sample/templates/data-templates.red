#[
    credits: #[
        credits_forms: #[
            first_name: none
            last_name: none
            tax_number: none
            phone_number: none
            email: none
            is_married: none
            applicant_finances: [applicant_finance: [
                credit_rating: none 
                loan_amount: none 
                salary: none
            ]]
        ]
    ]
]