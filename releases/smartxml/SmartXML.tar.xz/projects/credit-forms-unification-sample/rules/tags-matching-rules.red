#[
    credits: #[
        first_name: [
            "LoanApplication Applicant Name First" 
            "LoanApplication ApplicantInfo FullName FirstName" 
            "LoanApplication Applicant FullName FirstName"
        ]
        last_name: [
            "LoanApplication Applicant Name Last" 
            "LoanApplication ApplicantInfo FullName LastName" 
            "LoanApplication Applicant FullName LastName"
        ]
        tax_number: [
            "LoanApplication Applicant TaxID" 
            {LoanApplication ApplicantInfo TaxIdentificationNumber} 
            "LoanApplication Applicant SocialSecurityNumber"
        ]
        email: [
            "LoanApplication Applicant ContactInfo Email" 
            {LoanApplication ApplicantInfo ContactInfo EmailAddress} 
            {LoanApplication Applicant ContactInformation Email}
        ]
        phone_number: [
            "LoanApplication Applicant ContactInfo Phone" 
            {LoanApplication ApplicantInfo ContactInfo PhoneNumber} 
            {LoanApplication Applicant ContactInformation Phone}
        ]
        is_married: [
            "LoanApplication Applicant MaritalStatus" 
            "LoanApplication ApplicantInfo MaritalStatus"
        ]
        salary: [
            "LoanApplication FinancialInformation Income" 
            "LoanApplication FinancialInfo Salary"
        ]
        credit_rating: [
            "LoanApplication FinancialInformation CreditScore" 
            "LoanApplication FinancialInfo CreditRating"
        ]
        loan_amount: [
            {LoanApplication FinancialInformation RequestedLoanAmount} 
            "LoanApplication FinancialInfo LoanAmount"
        ]
    ]
]