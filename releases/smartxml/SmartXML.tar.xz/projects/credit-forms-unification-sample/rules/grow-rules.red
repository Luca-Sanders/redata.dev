credits: [
    applicant_finance: ["FinancialInfo" "FinancialInformation"]
]