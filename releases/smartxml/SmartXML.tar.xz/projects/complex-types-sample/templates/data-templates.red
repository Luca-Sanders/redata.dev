#[
    section-A: #[
        sample: #[
            name: none
            age: none
            height: none
            contact_phone: none
            contact_email: none
            salary: none
            salary_currency: none
            salary_in_usd: none
            is_sitizen: none
            is_marital: none
        ]
    ]
]