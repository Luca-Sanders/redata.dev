section-A: #[
    name: [
        "data name"
    ]
    age: [
        "data age"
    ]
    height: [
        "data height"
    ]
    contact_info: [
        "data contactInfo"
    ]
    is_sitizen: [
        "data isCitizen"
    ]
    salary: [
        "data salary"
    ]
    is_marital: [
        "data MaritalStatus"
    ]
]