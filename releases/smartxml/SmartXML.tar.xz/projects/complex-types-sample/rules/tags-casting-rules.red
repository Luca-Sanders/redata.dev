section-A: [
    integer-list: [[to-integer to-float] ["age" "height" "salary"]] 
    float-list: [[to-float] []] 
    bool-list: [[reduce to-word] ["is_sitizen" "is_marital"]]
]