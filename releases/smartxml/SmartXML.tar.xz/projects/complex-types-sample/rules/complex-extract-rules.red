section-A: [
    salary: [
        salary: [
            replace copy tag-value "$" "" 
            replace copy tag-value "€" ""
        ] 
        salary_currency: [
            result: none 
            if find tag-value "$" [result: "USD"] 
            if find tag-value "€" [result: "EUR"] 
            return result
        ] 
        salary_in_usd: [
            replace tag-value "$" "" 
            replace tag-value "€" "" 
            data: load-json read http://data.fixer.io/api/latest?access_key=4fa6a1818b68359cf90639fa4054980b 
            return round/even (data/rates/USD * (to-integer tag-value))
        ]
    ] 
    contact_info: [
        contact_phone: [
            parse tag-value [thru "phone:" copy phone to "email:"] 
            return phone
        ] 
        contact_email: [
            parse tag-value [thru "email:" copy email to end] 
            return email
        ]
    ] 
    is_marital: [
        is_marital: [
            replace tag-value "Single" "false" 
            replace tag-value "Married" "true"
        ]
    ]
]