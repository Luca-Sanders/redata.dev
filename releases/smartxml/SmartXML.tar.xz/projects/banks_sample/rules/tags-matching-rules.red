#[
    rabobank: #[
        first_name: [
            "LoanApplication Applicant FullName FirstName"
        ]
        fast_name: [
            "LoanApplication Applicant FullName LastName"
        ]
        tax_number: [
            "LoanApplication Applicant SocialSecurityNumber"
        ]
        email: [
            {LoanApplication Applicant ContactInformation Email}
        ]
        phone_number: [
            {LoanApplication Applicant ContactInformation Phone}
        ]
        is_married: [
            "LoanApplication Applicant MaritalStatus"
        ]
    ]
    barclays: #[
        first_name: [
            "LoanApplication Applicant Name First"
        ]
        fast_name: [
            "LoanApplication Applicant Name Last"
        ]
        tax_number: [
            "LoanApplication Applicant TaxID"
        ]
        email: [
            "LoanApplication Applicant ContactInfo Email"
        ]
        phone_number: [
            "LoanApplication Applicant ContactInfo Phone"
        ]
        is_married: [
            "LoanApplication Applicant MaritalStatus"
        ]
        salary: [
            "LoanApplication Employment Salary"
        ]
        credit_rating: [
            "LoanApplication FinancialInfo CreditRating"
        ]
        loan_amount: [
            "LoanApplication FinancialInfo LoanAmount"
        ]
    ]
    deutschebank: #[
        first_name: [
            "LoanApplication ApplicantInfo FullName FirstName"
        ]
        fast_name: [
            "LoanApplication ApplicantInfo FullName LastName"
        ]
        tax_number: [
            {LoanApplication ApplicantInfo TaxIdentificationNumber}
        ]
        phone_number: [
            {LoanApplication ApplicantInfo ContactInfo PhoneNumber}
        ]
        email: [
            {LoanApplication ApplicantInfo ContactInfo EmailAddress}
        ]
        is_married: [
            "LoanApplication ApplicantInfo MaritalStatus"
        ]
        salary: [
            "LoanApplication EmploymentInfo JobDetails Salary"
        ]
        credit_rating: [
            "LoanApplication FinancialInfo CreditRating"
        ]
        loan_amount: [
            "LoanApplication FinancialInfo LoanAmount"
        ]
    ]
]