rabobank: [
    inject-tag-to-every-children: [] 
    enumerate-nodes: [] 
    change-value-for-this-tag: [] 
    injection-tag-and-recipients: []
] 
barclays: [
    inject-tag-to-every-children: [] 
    enumerate-nodes: [] 
    change-value-for-this-tag: [] 
    injection-tag-and-recipients: []
] 
deutschebank: [
    inject-tag-to-every-children: [] 
    enumerate-nodes: [] 
    change-value-for-this-tag: [] 
    injection-tag-and-recipients: []
]