rabobank: [] 
barclays: [
    applicant_finances: ["FinancialInfo"]
] 
deutschebank: [
    applicant_finance: ["FinancialInfo"]
]