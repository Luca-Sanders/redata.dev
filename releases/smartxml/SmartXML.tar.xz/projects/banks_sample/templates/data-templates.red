#[
    rabobank: #[
        applicant_forms: #[
            guid: #guid
            first_name: none
            fast_name: none
            tax_number: none
            phone_number: none
            email: none
            is_married: none
            applicant_finances: [
                applicant_finance: [
                    credit_rating: none 
                    loan_amount: none 
                    salary: none
                ]
            ]
        ]
    ]
    barclays: #[
        applicant_forms: #[
            guid: #guid
            first_name: none
            fast_name: none
            tax_number: none
            phone_number: none
            email: none
            is_married: none
            applicant_finances: [
                credit_rating: none 
                loan_amount: none 
                salary: none
            ]
        ]
    ]
    deutschebank: #[
        applicant_forms: #[
            guid: #GUID
            first_name: none
            fast_name: none
            tax_number: none
            phone_number: none
            email: none
            is_married: none
            my_super_table_name: [
                applicant_finance: [
                    credit_rating: none 
                    loan_amount: none 
                    salary: none
                ]
            ]
        ]
    ]
]