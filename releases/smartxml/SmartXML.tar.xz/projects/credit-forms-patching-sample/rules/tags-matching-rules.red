credits: #[
    first_name: [
        "LoanApplication ApplicantInfo FullName FirstName" 
        "LoanApplication Applicant FullName FirstName" 
        "LoanApplication Applicant Name First"
    ]
    last_name: [
        "LoanApplication Applicant Name Last" 
        "LoanApplication ApplicantInfo FullName LastName" 
        "LoanApplication Applicant FullName LastName"
    ]
    tax_number: [
        "LoanApplication Applicant TaxID" 
        {LoanApplication ApplicantInfo TaxIdentificationNumber} 
        "LoanApplication Applicant SocialSecurityNumber" 
        {LoanApplicationUpdate Applicant SocialSecurityNumber} 
        "UpdateInfo ApplicantInfo TaxIdentificationNumber" 
        "ContactInfoUpdate Applicant TaxID"
    ]
    email: [
        "LoanApplication Applicant ContactInfo Email" 
        {LoanApplication ApplicantInfo ContactInfo EmailAddress} 
        {LoanApplication Applicant ContactInformation Email} 
        {LoanApplicationUpdate Applicant ContactInformation Email} 
        "UpdateInfo ApplicantInfo ContactInfo EmailAddress" 
        "ContactInfoUpdate Applicant ContactInfo Email"
    ]
    phone_number: [
        "LoanApplication Applicant ContactInfo Phone" 
        {LoanApplication ApplicantInfo ContactInfo PhoneNumber} 
        {LoanApplication Applicant ContactInformation Phone} 
        {LoanApplicationUpdate Applicant ContactInformation Phone} 
        "UpdateInfo ApplicantInfo ContactInfo PhoneNumber" 
        "ContactInfoUpdate Applicant ContactInfo Phone"
    ]
    is_married: [
        "LoanApplication Applicant MaritalStatus" 
        "LoanApplication ApplicantInfo MaritalStatus" 
        "UpdateInfo ApplicantInfo MaritalStatus" 
        "ContactInfoUpdate Applicant MaritalStatus" 
        "LoanApplicationUpdate Applicant isMarried"
    ]
    salary: [
        "LoanApplication FinancialInformation Income" 
        "LoanApplication FinancialInfo Salary"
    ]
    credit_rating: [
        "LoanApplication FinancialInformation CreditScore" 
        "LoanApplication FinancialInfo CreditRating"
    ]
    loan_amount: [
        {LoanApplication FinancialInformation RequestedLoanAmount} 
        "LoanApplication FinancialInfo LoanAmount"
    ]
]