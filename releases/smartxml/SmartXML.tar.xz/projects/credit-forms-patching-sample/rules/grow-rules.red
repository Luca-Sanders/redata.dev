credits: [
    applicant_finance: ["FinancialInfo" "EmploymentInformation"]
]