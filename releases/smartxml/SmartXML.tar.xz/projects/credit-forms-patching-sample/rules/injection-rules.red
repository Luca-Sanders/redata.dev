credits: [
    inject-tag-to-every-children: [tax_number] 
    enumerate-nodes: [] 
    change-value-for-this-tag: [] 
    injection-tag-and-recipients: []
]