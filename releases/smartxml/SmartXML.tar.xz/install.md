### Ubuntu:

```
sudo dpkg --add-architecture i386
sudo apt update
sudo apt install libgtk-3-0:i386
sudo apt install libcanberra-gtk3-module:i386
sudo apt install libcurl4-openssl-dev:i386
sudo apt install unixodbc:i386

sudo add-apt-repository "deb [arch=x32] http://deb.debian.org/debian/ sid main"

sudo apt-key adv --keyserver keyserver.ubuntu.com --recv-keys 605C66F00D6C9793 0E98404D386FA1D9 648ACFD622F3D138

sudo apt install libsqliteodbc:i386
```

edit next file to be sure that 32 bit version have right driver path:

```
sudo nano /etc/odbcinst.ini 
```

```
[SQLite32]
Description=SQLite3 ODBC Driver
Driver=/usr/lib/i386-linux-gnu/odbc/libsqlite3odbc.so
Setup=/usr/lib/i386-linux-gnu/odbc/libsqlite3odbc.so
UsageCount=1
```

For PostgreSQL:

```
sudo apt install odbc-postgresql:i386
```


### ArchLinux.

Uncomment (if commented) multilib support:

```
/etc/pacman.conf

[multilib]
Include = /etc/pacman.d/mirrorlist
```

```
sudo pacman -Syu
pacman -S base-devel
sudo pacman -S lib32-gtk3
sudo pacman -S lib32-glibc
sudo pacman -S lib32-sqlite
sudo pacman -S multilib-devel
sudo pacman -S gcc-multilib
sudo pacman -S lib32-gcc-libs
sudo pacman -S yay
yay -S lib32-unixodbc
```

Then:

```
git clone https://github.com/softace/sqliteodbc.git
cd sqliteodbc
CFLAGS=-m32 LDFLAGS=-m32 ./configure
make
sudo make install
```

run

```
sudo nano /etc/odbcinst.ini 
```

and add this section if not exists (after manual install it don't):

```
[SQLite32]
Description=SQLite3 ODBC Driver
Driver=/usr/local/lib/libsqlite3odbc.so
Setup=/usr/local/lib/libsqlite3odbc.so
UsageCount=1
```

`SQLite32` name could be changed. But every project should use this name as name of `odbc` driver.


Tested on Majiaro